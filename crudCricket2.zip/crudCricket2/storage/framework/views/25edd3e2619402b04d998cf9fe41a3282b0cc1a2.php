<!DOCTYPE html>
<html>
<head>
    <title>Phil Baxter Cricket Player database</title>
    <!--ItSolutionStuff.com-->
    <link rel="stylesheet" href="<?php echo asset('css/css.css')?>" type="text/css">
</head>
<body>

<div class="bg">
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>

</body>
</html>
<?php /**PATH /Users/phil/Sites/crudCricket2/resources/views/layouts/layout2.blade.php ENDPATH**/ ?>
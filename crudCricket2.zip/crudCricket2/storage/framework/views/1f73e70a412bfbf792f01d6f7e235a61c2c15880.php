<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Admin View: Country view</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="http://crudcricket2.test/">Main Menu</a>
                <a class="btn btn-success" href="<?php echo e(route('countrys.create')); ?>"> Create New Country</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $countrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($country->name); ?></td>
            <td>
                <form action="<?php echo e(route('countrys.destroy',$country->id)); ?>" method="POST">

                    <center>
                    <a class="btn btn-info" style="width:40%" href="<?php echo e(route('countrys.show',$country->id)); ?>">Show</a>
                    <a class="btn btn-primary" style="width:40%" href="<?php echo e(route('countrys.edit',$country->id)); ?>">Edit</a>
                    </center>

                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $countrys->links(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/phil/Sites/crudcricket2/resources/views/countrys/index.blade.php ENDPATH**/ ?>
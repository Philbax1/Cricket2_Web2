<!DOCTYPE html>
<html>
<head>
    <title>Phil Baxter Cricket Player database</title>
    <!--ItSolutionStuff.com-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>

<div class="container">
</br>
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH /Users/phil/Sites/crudcricket2/resources/views/players/layout.blade.php ENDPATH**/ ?>

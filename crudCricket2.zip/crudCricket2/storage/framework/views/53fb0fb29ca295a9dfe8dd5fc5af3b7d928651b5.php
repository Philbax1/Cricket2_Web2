<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Admin View: Player view</h2>

            </div>
            <div class="pull-right">

                <a class="btn btn-success" href="http://crudcricket2.test/">Main Menu</a>
                <a class="btn btn-success" href="<?php echo e(route('players.create')); ?>"> Create New Player</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?> <!--Allows used to see their actions worked coorectly-->
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered"> <!--Data Table-->
        <tr>
            <th>No</th>
            <th>Name</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($player->playerName); ?></td>
            <td>
                <form action="<?php echo e(route('players.destroy',$player->id)); ?>" method="POST"> <!--uses id to delete selected country-->

                    <center>
                    <a class="btn btn-info" href="<?php echo e(route('players.show',$player->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('players.edit',$player->id)); ?>">Edit</a>

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                    </center>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $players->links(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/phil/Sites/crudcricket2/resources/views/players/index.blade.php ENDPATH**/ ?>
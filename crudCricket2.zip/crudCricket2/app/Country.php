<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    protected $fillable = [
        'name','countryFlag',
    ];

    public function country()  //creates relational join
    {
        return $this->belongsTo('App\Country');
    }
}

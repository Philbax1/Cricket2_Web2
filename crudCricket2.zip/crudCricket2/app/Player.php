<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Player extends Model
{
    protected $fillable = [
        'playerName','age','role','batting','bowling','image','odiRuns'
    ];

    public function players()  //creates relational join
    {
        return $this->hasMany('App\Country');
    }
}

<!DOCTYPE html>
<html>
<head>
    <title>Phil Baxter Cricket Player database</title>
    <!--ItSolutionStuff.com-->
    <link rel="stylesheet" href="<?php echo asset('css/css.css')?>" type="text/css">
</head>
<body>

<div class="bg">
    <div class="container">
        @yield('content')
    </div>
</div>

</body>
</html>

@extends('layouts.layout')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Admin View: Player view</h2>

            </div>
            <div class="pull-right">

                <a class="btn btn-success" href="http://crudcricket2.test/">Main Menu</a>
                <a class="btn btn-success" href="{{ route('players.create') }}"> Create New Player</a>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success')) <!--Allows used to see their actions worked coorectly-->
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered"> <!--Data Table-->
        <tr>
            <th>No</th>
            <th>Name</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($players as $player)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $player->playerName }}</td>
            <td>
                <form action="{{ route('players.destroy',$player->id) }}" method="POST"> <!--uses id to delete selected country-->

                    <center>
                    <a class="btn btn-info" href="{{ route('players.show',$player->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('players.edit',$player->id) }}">Edit</a>

                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                    </center>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

    {!! $players->links() !!}

@endsection

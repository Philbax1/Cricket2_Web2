@extends('layouts.layout2')

@section('content')

        <h1>Welcome to the cricket database</h1>

    <table id="mainMenu">
        <tr>
            <th>Public View</th>
            <th>Admin View</th>
        </tr>
        <hr width="80%">
        <tr>
            <td><a target="_blank" href="//mariadb.ict.op.ac.nz/~baxtpj1/Cricket/public/">Basic access view</a></td><!--Link to original laravel project-->
            <td><a href = "{{route("players.index")}}">Admin View players</a></td><!--To admin player view-->
        </tr>
        <tr>
            <td></td>
            <td><a href = "{{route("countrys.index")}}">Admin View countrys</a></td><!--To admin country view-->
         </tr>
    </table>

@endsection

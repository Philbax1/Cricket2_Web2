@extends('layouts.layout')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Admin View: Country view</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="http://crudcricket2.test/">Main Menu</a>
                <a class="btn btn-success" href="{{ route('countrys.create') }}"> Create New Country</a>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($countrys as $country)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $country->name }}</td>
            <td>
                <form action="{{ route('countrys.destroy',$country->id) }}" method="POST">

                    <center>
                    <a class="btn btn-info" style="width:40%" href="{{ route('countrys.show',$country->id) }}">Show</a>
                    <a class="btn btn-primary" style="width:40%" href="{{ route('countrys.edit',$country->id) }}">Edit</a>
                    </center>

                </form>
            </td>
        </tr>
        @endforeach
    </table>

    {!! $countrys->links() !!}

@endsection
